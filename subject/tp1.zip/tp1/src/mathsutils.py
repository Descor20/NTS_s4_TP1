from math import pi, cos, sin
from random import randint


def degreetorad(theta):
    """
    theta : float
    return the conversion in radian
    """
    pass

def multmatvector(M: list[list[float]], X: list[float]):
    """
    M : matrix of size n * m
    X : vector of size m
    return the product of M and X
    """
    pass

def multmat(M1: list[list[float]], M2: list[list[float]]):
    """
    M1 : matrix of size n * m
    M2 : matrix of size m * p
    return the product of M1 and M2
    """
    pass

def r2d(theta):
    """
    theta : angle in degrees
    return the 2d rotation matrix of angle theta
    """
    pass

def move2d(x, y, r, d):
    """
    x, y : initial position
    r : rotation matrix representing the current direction
    d : distance
    return the new coordinates
    """
    pass
    
def ru3d(theta):
    """
    theta : angle in degrees
    return the 3d rotation matrix of angle theta along the axis ru
    """
    pass
    
def rl3d(theta):
    """
    theta : angle in degrees
    return the 3d rotation matrix of angle theta along the axis rl
    """
    pass
    
def rh3d(theta):
    """
    theta : angle in degrees
    return the 3d rotation matrix of angle theta along the axis rh
    """
    pass

def move3d(x, y, z, r, d):
    """
    x, y, z : initial position
    r : rotation matrix representing the current direction
    d : distance
    return the new coordinates
    """
    pass
