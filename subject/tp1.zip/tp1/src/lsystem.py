
from mathsutils import *
from drawing.line import Line
from lsystems.lsystem2d import *
from lsystems.lsystem3d import *
import random

def derivation(axiom, rules):
    """
    axiom : string
    rules : dictionary
    return the result of the derivation
    """
    pass
    

def generation(axiom, rules, n):
    """
    axiom : string
    rules : dictionary
    n : integer
    return the result of n successive derivations
    """
    pass
    
def axiomtoline2d(gen : str, p : tuple[float, float], lsys : LSystem2d) -> list[Line]:
    pass

def axiomtoline3d(gen : str, p : tuple[float, float, float], lsys : LSystem3d) -> list[tuple[Line, int]]:
    pass
    
def axiomtoline3drand(gen : str, p : tuple[float, float, float], lsys : LSystem3d, randmax : float) -> list[tuple[Line, int]]:
    pass
