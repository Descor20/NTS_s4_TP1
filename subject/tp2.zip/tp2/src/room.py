class Room:
  
    def __init__(self,size_x,size_y,corner_x,corner_y):
        self.size_x = size_x
        self.size_y = size_y
        self.corner_x = corner_x
        self.corner_y = corner_y
        


